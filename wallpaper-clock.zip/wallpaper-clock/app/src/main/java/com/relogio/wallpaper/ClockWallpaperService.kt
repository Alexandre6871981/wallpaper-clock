package com.relogio.wallpaper

import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.max

class ClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {

        private val handler = Handler(Looper.getMainLooper())
        private val prefs = Prefs.get(this@ClockWallpaperService)

        private var visible = false
        private var surfaceWidth = 0
        private var surfaceHeight = 0
        private var background: Bitmap? = null

        private val bgPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        private val dias = arrayOf("DOM.", "SEG.", "TER.", "QUA.", "QUI.", "SEX.", "SÁB.")
        private val meses = arrayOf(
            "JAN.", "FEV.", "MAR.", "ABR.", "MAI.", "JUN.",
            "JUL.", "AGO.", "SET.", "OUT.", "NOV.", "DEZ."
        )

        // Redesenha a cada virada de minuto, que é quando o relógio muda.
        private val ticker = object : Runnable {
            override fun run() {
                draw()
                if (visible) {
                    val now = System.currentTimeMillis()
                    handler.postDelayed(this, 60_000L - (now % 60_000L) + 50L)
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            handler.removeCallbacks(ticker)
            background?.recycle()
            background = null
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(ticker)
            if (visible) handler.post(ticker)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceWidth = width
            surfaceHeight = height
            loadBackground()
            draw()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            visible = false
            handler.removeCallbacks(ticker)
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            if (key == Prefs.KEY_BG_VERSION) loadBackground()
            draw()
        }

        private fun loadBackground() {
            background?.recycle()
            background = null

            val file = Prefs.backgroundFile(this@ClockWallpaperService)
            if (!file.exists() || surfaceWidth <= 0 || surfaceHeight <= 0) return

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return

            var sample = 1
            while (bounds.outWidth / (sample * 2) >= surfaceWidth &&
                bounds.outHeight / (sample * 2) >= surfaceHeight
            ) {
                sample *= 2
            }

            val src = BitmapFactory.decodeFile(
                file.path,
                BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return

            // Corte central: preenche a tela inteira sem distorcer a imagem.
            val s = max(
                surfaceWidth / src.width.toFloat(),
                surfaceHeight / src.height.toFloat()
            )
            val dw = src.width * s
            val dh = src.height * s
            val out = Bitmap.createBitmap(surfaceWidth, surfaceHeight, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(
                src, null,
                RectF(
                    (surfaceWidth - dw) / 2f, (surfaceHeight - dh) / 2f,
                    (surfaceWidth + dw) / 2f, (surfaceHeight + dh) / 2f
                ),
                bgPaint
            )
            src.recycle()
            background = out
        }

        private fun draw() {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) drawFrame(canvas)
            } catch (_: Exception) {
                // Superfície indisponível neste momento; tenta de novo no próximo ciclo.
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (_: Exception) {
                    }
                }
            }
        }

        private fun drawFrame(canvas: Canvas) {
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()

            val bg = background
            if (bg != null) {
                canvas.drawBitmap(bg, 0f, 0f, null)
            } else {
                val p = Paint().apply {
                    shader = LinearGradient(
                        0f, 0f, 0f, h,
                        intArrayOf(0xFF1F5FA8.toInt(), 0xFFF2A65A.toInt()),
                        null, Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, w, h, p)
            }

            val color = prefs.getInt(Prefs.KEY_COLOR, Color.BLACK)
            val scale = prefs.getInt(Prefs.KEY_SCALE, 100) / 100f
            val pos = prefs.getInt(Prefs.KEY_POS, 30) / 100f
            val use24 = prefs.getBoolean(Prefs.KEY_24H, false)

            val cal = Calendar.getInstance()
            var hour = if (use24) cal.get(Calendar.HOUR_OF_DAY) else cal.get(Calendar.HOUR)
            if (!use24 && hour == 0) hour = 12
            val minute = cal.get(Calendar.MINUTE)
            val timeText = "%02d%02d".format(hour, minute)
            val dateText = "${dias[cal.get(Calendar.DAY_OF_WEEK) - 1]} " +
                "${meses[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.DAY_OF_MONTH)}"

            // Ajusta o tamanho para o relógio ocupar ~62% da largura (vezes a escala).
            timePaint.color = color
            timePaint.textSize = 100f
            val measured = timePaint.measureText(timeText)
            timePaint.textSize = 100f * (w * 0.62f * scale) / measured

            val textBounds = Rect()
            timePaint.getTextBounds(timeText, 0, timeText.length, textBounds)
            val digitsHeight = textBounds.height().toFloat()

            val top = h * pos
            val timeBaseline = top + digitsHeight
            canvas.drawText(timeText, w / 2f, timeBaseline, timePaint)

            datePaint.color = color
            datePaint.textSize = timePaint.textSize * 0.17f
            canvas.drawText(dateText, w / 2f, top - datePaint.textSize * 0.35f, datePaint)
        }
    }
}
