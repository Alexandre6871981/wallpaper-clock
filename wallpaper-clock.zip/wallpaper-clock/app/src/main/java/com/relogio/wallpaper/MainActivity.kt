package com.relogio.wallpaper

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {

    private val prefs by lazy { Prefs.get(this) }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) return@registerForActivityResult
            Thread {
                val ok = try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(Prefs.backgroundFile(this)).use { out ->
                            input.copyTo(out)
                        }
                    }
                    true
                } catch (e: Exception) {
                    false
                }
                runOnUiThread {
                    if (ok) {
                        prefs.edit().putLong(Prefs.KEY_BG_VERSION, System.currentTimeMillis()).apply()
                        Toast.makeText(this, "Imagem de fundo atualizada", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Não foi possível abrir a imagem", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        root.addView(TextView(this).apply {
            text = "Relógio Wallpaper"
            textSize = 24f
            setTextColor(Color.BLACK)
        })
        root.addView(label("Escolha uma imagem da galeria e ajuste o relógio. Depois toque em \"Definir como papel de parede\"."))

        root.addView(Button(this).apply {
            text = "Escolher imagem de fundo"
            setOnClickListener { pickImage.launch("image/*") }
        })

        // Cor
        root.addView(label("Cor do relógio"))
        val colors = linkedMapOf(
            "Preto" to Color.BLACK,
            "Branco" to Color.WHITE,
            "Laranja" to 0xFFF2A65A.toInt(),
            "Azul" to 0xFF4FA3FF.toInt(),
            "Vermelho" to 0xFFE0453A.toInt()
        )
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEach { (name, value) ->
            colorRow.addView(Button(this).apply {
                text = name
                textSize = 11f
                setOnClickListener { prefs.edit().putInt(Prefs.KEY_COLOR, value).apply() }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(colorRow)

        // Tamanho
        root.addView(label("Tamanho do relógio"))
        root.addView(seek(50, 150, Prefs.KEY_SCALE, 100))

        // Posição
        root.addView(label("Posição vertical"))
        root.addView(seek(0, 80, Prefs.KEY_POS, 30))

        // 24h
        root.addView(Switch(this).apply {
            text = "Formato 24 horas"
            isChecked = prefs.getBoolean(Prefs.KEY_24H, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.KEY_24H, checked).apply()
            }
            setPadding(0, dp(16), 0, dp(16))
        })

        root.addView(Button(this).apply {
            text = "Definir como papel de parede"
            setOnClickListener { applyWallpaper() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.DKGRAY)
        gravity = Gravity.START
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun seek(min: Int, max: Int, key: String, default: Int) = SeekBar(this).apply {
        this.max = max - min
        progress = prefs.getInt(key, default) - min
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) prefs.edit().putInt(key, p + min).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun applyWallpaper() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, ClockWallpaperService::class.java)
        )
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
