package com.relogio.wallpaper

import android.content.Context
import android.content.SharedPreferences
import java.io.File

object Prefs {
    private const val NAME = "clock_prefs"

    const val KEY_COLOR = "color"
    const val KEY_SCALE = "scale"      // 50..150 (porcentagem)
    const val KEY_POS = "pos"          // 0..100 (altura na tela, em %)
    const val KEY_24H = "h24"
    const val KEY_BG_VERSION = "bg_version"

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun backgroundFile(context: Context): File =
        File(context.filesDir, "background.jpg")
}
