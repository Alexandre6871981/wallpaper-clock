# Relógio Wallpaper

Papel de parede animado para Android: mostra uma imagem da sua galeria com um relógio grande e a data em português por cima, atualizados em tempo real.

## Como gerar o app

1. Instale o **Android Studio** (versão recente) no computador.
2. Extraia este ZIP e abra a pasta `RelogioWallpaper` pelo Android Studio (File > Open).
3. Aguarde o Gradle sincronizar. Se pedir, aceite baixar o Gradle e o SDK 34.
4. Ative a **Depuração USB** no celular e conecte no computador.
5. Clique em **Run** (triângulo verde). O app será instalado no celular.
   - Para ter um arquivo APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

## Como usar

1. Abra o app **Relógio Wallpaper**.
2. Toque em **Escolher imagem de fundo** e selecione a foto na galeria.
3. Ajuste a cor, o tamanho e a posição do relógio.
4. Toque em **Definir como papel de parede** e confirme.

## Personalização

- **Fonte:** em `ClockWallpaperService.kt`, troque `Typeface.create("sans-serif-condensed", ...)` por uma fonte sua. Coloque o arquivo `.ttf` em `res/font/` e use `resources.getFont(R.font.sua_fonte)`.
- **Largura do relógio:** a linha com `w * 0.62f` define quanto da tela ele ocupa.
- **Formato 12h/24h:** há uma chave no app.
